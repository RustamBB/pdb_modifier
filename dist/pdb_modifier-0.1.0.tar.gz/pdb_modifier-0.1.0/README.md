# pdb_modifier

A simple Python package to modify PDB files by adding " F F F" at the end of coordinate lines.

## Installation

```bash
pip install pdb_modifier